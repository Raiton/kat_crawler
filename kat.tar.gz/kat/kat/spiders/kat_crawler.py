from scrapy.selector import HtmlXPathSelector
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.contrib.spiders import CrawlSpider, Rule
from kat.items import KatItem
from scrapy.http import Request
from urlparse import urljoin

class KatCrawlerSpider(CrawlSpider):
    name = 'kat_crawler'
    start_urls = ['http://kat.ph']

    rules = (
        #Rule(SgmlLinkExtractor(allow=r'Items/'), callback='parse_item', follow=True),

    )

    def parse(self, response):
        hxs = HtmlXPathSelector(response)
        # d=hxs.select("//h2/a[@href='/tv/']/../../div/table//tr[position()>1]//div[@class='torrentname']/a/text()")
        d=hxs.select("//h2/a[@href='/tv/']/../../div/table//tr[position()>1]")

        items=[]
        for ite in d:
            i = KatItem()
            i['name']=ite.select(".//div[@class='torrentname']/a/text()").extract()
            i['size']=ite.select(".//td[@class='nobr center']//text()").extract()
            age_temp=ite.select(".//td[4]//text()").extract()[0].replace(u'\xa0',u' ')
            i['age']=[age_temp]
            i['seed']=ite.select(".//td[5]//text()").extract()
            # Broken
            #i['url']=ite.select(".//a[@title='Download torrent file']/@href").extract()
            
            #fix
            torrent_description=  urljoin(response.url,ite.select(".//div[@class='torrentname']/a/@href").extract()[0])
            request = Request(torrent_description, callback=self.parse_torrent_description)
            request.meta['item'] = i
            yield request

    def parse_torrent_description(self,response):
        hxs = HtmlXPathSelector(response)

        item = response.meta['item']
        item['url']=hxs.select("//a[@title='Download verified torrent file']/@href").extract()
        yield item
